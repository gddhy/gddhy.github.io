import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class fileHex {

    public static void copyUnknow(String gifPath,String putPath) {
        File file1 = new File(gifPath);
		File file2 = new File(putPath);
		if(!file2.exists()){
			file2.mkdirs();
		}
        String[] list = file1.list();
        for (int i = 0;i<list.length;i++){
            boolean isQqHex = isQqHexGif(new File(file1,list[i]).getPath());
            System.out.println((i+1)+" : "+list[i]);
            System.out.println("isHex : "+isQqHex);
            if (isQqHex){
                File f = new File(file1,list[i]);
                boolean b = copyGif(f.getPath(),new File(file2,list[i]+".gif").getPath());
                //f.delete();
                System.out.println("toGif : "+b);
            }
        }
        System.out.println("done");
    }

    public static boolean isQqHexGif(String path){
        String hex = null;
        try {
            File file = new File(path);
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
            byte[] a = new byte[1024];
            int count = -1;
            StringBuilder sb = new StringBuilder();
            while ((count = in.read(a)) != -1) {
                for (int i = 0; i < count; i++) {
                    convertByte2Hex(a[i], sb);
                }
            }
            hex = sb.toString();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return hex.substring(0,12).equals("474846393960");
    }

    public static boolean copyGif(String oldPath,String newPath){
        String hex = null;
        try {
            File file = new File(oldPath);
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
            byte[] a = new byte[1024];
            int count = -1;
            StringBuilder sb = new StringBuilder();
            while ((count = in.read(a)) != -1) {
                for (int i = 0; i < count; i++) {
                    convertByte2Hex(a[i], sb);
                }
            }
            hex = sb.toString();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return writeNew2Binary(newPath,gifHexFile(hex));
    }

    private static void convertByte2Hex(byte b, StringBuilder sb) {
        int number = b & 0x00ff;
        if(number<16){
            sb.append(0);
        }
        sb.append(Integer.toHexString(number));
    }

    public static String convertHex2ASCII(String hexString) {
        int length = hexString.length();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length - 1; i += 2) {
            String s = hexString.charAt(i) + "" + hexString.charAt(i + 1);
            int parseInt = Integer.parseInt(s, 16);
            if (parseInt < 32 && parseInt != 10) {
                sb.append(" ");
            } else {
                sb.append((char) parseInt);
            }
        }
        return sb.toString();
    }

    /**
     * 去掉指定字符串的开头的指定字符
     * @param stream 原始字符串
     * @param trim 要删除的字符串
     * @return
     */
    private static String StringStartTrim(String stream, String trim) {
        // null或者空字符串的时候不处理
        if (stream == null || stream.length() == 0 || trim == null || trim.length() == 0) {
            return stream;
        }
        // 要删除的字符串结束位置
        int end;
        // 正规表达式
        String regPattern = "[" + trim + "]*+";
        Pattern pattern = Pattern.compile(regPattern, Pattern.CASE_INSENSITIVE);
        // 去掉原始字符串开头位置的指定字符
        Matcher matcher = pattern.matcher(stream);
        if (matcher.lookingAt()) {
            end = matcher.end();
            stream = stream.substring(end);
        }
        // 返回处理后的字符串
        return stream;
    }

    private static String gifHexFile(String qqFileHex){
        if(qqFileHex ==null ) return null;
        String last = new String (StringStartTrim(qqFileHex, "474846393960"));
        return "474946383961"+last;
    }

    /**
     * 将替换后的16进制字符串写回文件
     * write replaced original String to file
     *
     * @param replaced
     * @param filePath
     * @throws NumberFormatException
     */
    private static boolean writeNew2Binary(String filePath, String replaced){
        if (replaced == null) return false;
        FileOutputStream fout = null;
        try {
            fout = new FileOutputStream(new File(filePath));

            for (int i = 0; i < replaced.length(); i = i + 2) {
                fout.write(Integer.parseInt(replaced.substring(i, i + 2), 16));
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}

