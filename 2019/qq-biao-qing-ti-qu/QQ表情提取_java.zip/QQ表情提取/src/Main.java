import java.io.*;
import java.util.*;

public class Main
{
	//腾讯QQ表情目录
	public static File tencentFile = new File("/sdcard/tencent/MobileQQ/.emotionsm");
	//储存目录
	public static File putFile = new File("/sdcard/QQ表情提取");
	
	public static void main(String[] args)
	{
		while(true){
			init();
		}
	}
	
	public static void init(){
		System.out.println("QQ表情提取工具");
		System.out.println("请选择显示方式");
		System.out.println("1.显示名称及简介(推荐)");
		System.out.println("2.显示所有可提取目录(无索引文件无法完全提取)");
		if(!putFile.exists()){
			putFile.mkdirs();
		}
		Scanner input = new Scanner(System.in);
		System.out.print("请选择: ");
		int i = input.nextInt();
		switch(i){
			case 1:
				Utils.show();
				break;
			case 2:
				showAll();
				break;
			default:
			System.out.println("输入有误，请重试");
			System.out.println();
		}
	}
	
	public static void showAll(){
		String[] list = tencentFile.list();
		for(int i=0;i<list.length;i++){
			System.out.println("id："+list[i]);
		}
		Scanner input = new Scanner(System.in);

		System.out.print("请输入id: ");
		String text = input.next();
		File file = new File(tencentFile,text);
		if (file.exists()){
			fileHex.copyUnknow(file.getPath(),putFile.getPath());
		} else {
			System.out.println("输入有误");
		}
	}
}
